<template>
  <div class="p-4">
    <h1>Frontend Kelompok 1</h1>
    <p>Ini contoh front end sederhana.</p>

    <Home />
  </div>
</template>

<script setup>
import Home from './pages/Home.vue'
</script>

<style>
body {
  font-family: Arial, sans-serif;
  margin: 0;
}
</style>